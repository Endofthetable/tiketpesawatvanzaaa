<?php

$conn = mysqli_connect('localhost', 'root', '', 'e_tiket_evanza');

?>